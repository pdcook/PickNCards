# Pick N Cards
--------------------

Pick any number of cards each pick phase! Configurable in settings!

This mod was made to replace PickTwoCards, who's implementation was incompatible with several other mods.

# Draw N Cards (New in v0.1.0!)
-------------------------------

Pick how many cards are drawn from the deck during each pick phase! Configurable in settings up to 20 cards!

# Card Draw Delay (New in v0.2.0!)

Change how long the delay between each card draw is. Online, each player may have a different setting. Vanilla default is 0.1 seconds.

---

Thanks to Willis for the icon!
